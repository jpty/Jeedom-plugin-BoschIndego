<?php

include "../../core/class/BoschIndego.class.php";

$BoschIndego= new BoschIndego();
$BoschIndego-> getJson(1);
